<?php

require_once( __DIR__ . '/functions/menus.php');
require_once( __DIR__ . '/functions/projects.php');
require_once( __DIR__ . '/functions/scripts.php');




